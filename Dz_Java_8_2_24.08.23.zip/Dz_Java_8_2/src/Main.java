import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Используя рекурсию, написать метод вычисления факториала числа n (n!), вводимого с клавиатуры.
        Scanner scr = new Scanner(System.in);
        System.out.println("Введите число n ");
        int n = scr.nextInt();
        System.out.print("Факториал числа  "+ n+ " = !" );
        System.out.print(getFactorial(n));

    }
    private static int getFactorial(int n) {
        if (n <= 1) {
            return 1;
        }
        else {
            return n * getFactorial(n - 1);
        }
    }
}