public class Main {
    public static void main(String[] args) {
        //Задание 1.
        //Сделайте перегруженные методы для перемножения 2-х, 3-х и 4-х чисел.
        // В методе умножения 3-х чисел используйте вызов метода для 2-х чисел.
        // В методе умножения 4-х чисел – вызов метода для 3-х чисел.
        System.out.println(getMultiplicationOfNumbers(2,3));
        System.out.println(getMultiplicationOfNumbers(2,3,2));
        System.out.println(getMultiplicationOfNumbers(2,3,2,4));

    }
    private static int getMultiplicationOfNumbers (int number1, int number2) {
        int f = number1*number2;
        return  f;
    }
    private static int getMultiplicationOfNumbers (int number1, int number2, int number3) {
        int d = getMultiplicationOfNumbers (number1, number2)*number3;
        return  d;
    }
    private static int getMultiplicationOfNumbers (int number1, int number2, int number3,int number4) {
        int s = getMultiplicationOfNumbers (number1, number2,number3)*number4;
        return  s;
    }
}