import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        //Создайте массив из 5 строк.
        // Используя метод length() строк,
        // найдите строку с наибольшей длиной и строк с наименьшей длиной.
        //Выведите массив и полученный строки в консоль.
        String[] string = {"h", "hydrsradssa", "gfyt", "hgutryrsrz", "ghk"};

        int[] stringNumSort = getLength(string).clone();
        Arrays.sort(stringNumSort);

        int i = 0;

        for (int num : getLength(string)) {


            if (num == stringNumSort[0]) {
                System.out.println("Строка с наименьшей длиной " + string[i]);
            }


            if (num == stringNumSort[string.length - 1]) {
                System.out.println("Строка с наибольшей длиной " + string[i]);
            }

            i++;


        }
    }


    private static int[] getLength(String... strings) {
        int[] strLength = new int[strings.length];
        for (int i = 0; i < strings.length; i++) {
            strLength[i] = strings[i].length();

        }
        return strLength;


    }
}