import java.util.Arrays;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        //Создайте массив из 8 случайных целых чисел из интервала [1;50]
        //Выведите массив на консоль в строку.
        //Замените каждый элемент с нечетным индексом на ноль.
        //Снова выведете массив на консоль в отдельной строке.
        //Отсортируйте массив по возрастанию.
        //Снова выведете массив на консоль в отдельной строке.
        int[] intArray = new int[8];

        for (int i = 0; i < intArray.length; i++) {
            Random rnd = new Random();
            int number = rnd.nextInt(51);
            intArray[i] = number;

        }
        String asString = Arrays.toString(intArray);
        System.out.println(asString);
        System.out.println();

        for (int i = 0; i < intArray.length; i++) {
            if (i%2 != 0) {
                intArray[i] = 0;
            }

        }
        String asString2 = Arrays.toString(intArray);
        System.out.println(asString2);
        System.out.println();
        Arrays.sort(intArray);
        String asString3 = Arrays.toString(intArray);
        System.out.println(asString3);



    }

}